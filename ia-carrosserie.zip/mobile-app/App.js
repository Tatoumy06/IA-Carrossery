import React from 'react';
import { View, Text } from 'react-native';
export default function App() {
  return (
    <View><Text>IA Carrosserie Mobile App</Text></View>
  );
}