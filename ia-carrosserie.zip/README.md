# IA Carrosserie

Projet IA pour diagnostic automobile.

## Démarrage
- Backend (Python + FastAPI)
- Frontend (React Native)
- Vision IA avec YOLOv8
- Chatbot OpenAI